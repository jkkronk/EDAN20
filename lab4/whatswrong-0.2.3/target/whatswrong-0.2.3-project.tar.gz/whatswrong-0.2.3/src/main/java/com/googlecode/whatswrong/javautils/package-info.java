/**
 * The javautils package contains classes that are generally useful and not
 * specific to any kind of project.
 */
package com.googlecode.whatswrong.javautils;